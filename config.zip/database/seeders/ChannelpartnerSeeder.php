<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\baseconst\ChannelPartner;

class ChannelpartnerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

    }
}
