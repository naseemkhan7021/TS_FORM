<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePrimaryMembersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('primary_members', function (Blueprint $table) {
            $table->id('iMemberID');
            $table->string('sMember_FirstName', 50);
            $table->string('sMember_MiddleName', 50);
            $table->string('sMember_LastName', 50);
            $table->string('sMember_FullName', 100);
            $table->string('sOccupation', 50);
            $table->string('sPanCard', 20);
            $table->string('sPanCard_Photo', 191);
            $table->string('sAadhaarCard', 20);
            $table->string('sAadhaarCard_Photo', 191);

            $table->unsignedBigInteger('iNationalityID_FK')->default(1);
            $table->foreign('iNationalityID_FK')->references('nationality_id')->on('nationalities')->onDelete('cascade');


            $table->unsignedBigInteger('iGenderID_FK')->default(1);
            $table->foreign('iGenderID_FK')->references('gender_id')->on('genders')->onDelete('cascade');

            // $table->unsignedBigInteger('iNativePlaceID_FK')->default(1);
            // $table->foreign('iNativePlaceID_FK')->references('templatehead_ID')->on('payment_template_heads')->onDelete('cascade');


            $table->unsignedBigInteger('iPurchased_UnitID_FK')->default(1);
            $table->foreign('iPurchased_UnitID_FK')->references('iID')->on('projectunits')->onDelete('cascade');




            $table->string('sMobileNo1', 20);
            $table->string('sMobileNo2', 20);
            $table->string('sEmailID1', 100);
            $table->string('sEmailID2', 100);

            $table->string('sResidentialAddress1', 100);
            $table->string('sResidentialAddress2', 100);
            $table->string('sPinCode', 10);
            $table->string('sCity', 50);

            $table->string('dtDOBK', 20);
            $table->string('dtDOB', 20);

            $table->boolean('bactive')->default(true);
            $table->integer('user_created')->default(0);
            $table->integer('user_updated')->default(0);
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
        });
    }



    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('primary_members');
    }
}
