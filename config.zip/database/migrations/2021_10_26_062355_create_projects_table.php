<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProjectsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('projects', function (Blueprint $table) {
            $table->id('ProjectID');
            $table->string('sProjectName', 150);
            $table->string('sLocation', 150);
            $table->string('sReraID', 50);
            $table->date('dtStart')->useCurrent();
            $table->integer('iNoofWings')->default(0);
            $table->integer('iNoofFloors')->default(0);
            $table->integer('iShops')->default(0);
            $table->integer('iOffice')->default(0);
            $table->integer('iFlatPerFloor')->default(0);
            $table->integer('mDevelopmentCostPerSqft')->default(0);
            $table->integer('iSuperLoadingPercentage')->default(0);
            $table->integer('iLoadingPercentage')->default(0);
            $table->boolean('bactive')->default(true);
            $table->integer('user_created')->default(0);
            $table->integer('user_updated')->default(0);
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('projects');
    }
}
