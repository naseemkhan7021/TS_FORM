<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProjectwingfloorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('projectwingfloors', function (Blueprint $table) {
            $table->id('iProjectWingFloorID');
            $table->unsignedBigInteger('iProjectID_FK')->default(1);
            $table->foreign('iProjectID_FK')->references('ProjectID')->on('projects')->onDelete('cascade');
            $table->unsignedBigInteger('iProjectWingID_FK')->default(1);
            $table->foreign('iProjectWingID_FK')->references('iProjectWingID')->on('projectwings')->onDelete('cascade');
            $table->string('sFloorDescription', 50);
            $table->string('iFloor', 10);
            $table->smallInteger('iUnitsperfloor');
            $table->boolean('bactive')->default(true);
            $table->integer('user_created')->default(0);
            $table->integer('user_updated')->default(0);
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('projectwingfloors');
    }
}
