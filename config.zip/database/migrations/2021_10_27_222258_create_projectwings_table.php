<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProjectwingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('projectwings', function (Blueprint $table) {
            $table->id('iProjectWingID');
            $table->unsignedBigInteger('iProjectID_FK')->default(1);
            $table->foreign('iProjectID_FK')->references('ProjectID')->on('projects')->onDelete('cascade');
            $table->string('sWingDescription', 100);
            $table->string('sWingAbbr', 10);
            $table->smallInteger('iFloors');
            $table->boolean('bactive')->default(true);
            $table->integer('user_created')->default(0);
            $table->integer('user_updated')->default(0);
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('projectwings');
    }
}
