<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLeadsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('leads', function (Blueprint $table) {
            $table->id('lead_id');
            $table->string('first_name', 50);
            $table->string('middle_name', 50);
            $table->string('last_name', 50);
            $table->string('full_name', 191);
            $table->string('mobile',15);
            $table->string('email', 100);
            $table->string('required_sales_unit', 100);
            $table->string('company_name', 100);
            $table->string('occupation', 50);
            $table->string('designation', 50);
            $table->string('lead_feedback', 200);
            $table->unsignedBigInteger('current_leadstatus_id');
            $table->foreign('current_leadstatus_id')->references('leadstatus_id')->on('lead_statuses')->onDelete('cascade');
            $table->unsignedBigInteger('current_source_id');
            $table->foreign('current_source_id')->references('source_id')->on('lead_sources')->onDelete('cascade');
            $table->unsignedBigInteger('current_propertystatus_id');
            $table->foreign('current_propertystatus_id')->references('propertystatus_id')->on('property_statuses')->onDelete('cascade');
            $table->smallInteger('lead_min_range');
            $table->smallInteger('lead_max_range');
            $table->smallInteger('lead_current_range');
            $table->string('residental_address', 191);
            $table->timestamp('dtfollowdate')->useCurrent();
            $table->timestamp('registered_dt')->useCurrent();
            $table->boolean('bactive')->default(true);
            $table->integer('user_created')->default(0);
            $table->integer('user_updated')->default(0);
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('leads');
    }
}
