<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLeadFollowupsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('lead_followups', function (Blueprint $table) {

            $table->id('iFollowUpID');

            $table->unsignedBigInteger('lead_id_FK')->default(1);
            $table->foreign('lead_id_FK')->references('lead_id')->on('leads')->onDelete('cascade');

            $table->unsignedBigInteger('lead_oldstatus_FK')->default(1);
            $table->foreign('lead_oldstatus_FK')->references('leadstatus_id')->on('lead_statuses')->onDelete('cascade');

            $table->unsignedBigInteger('lead_newstatus_FK')->default(1);
            $table->foreign('lead_newstatus_FK')->references('leadstatus_id')->on('lead_statuses')->onDelete('cascade');


            $table->timestamp('current_dt')->useCurrent();
            $table->timestamp('nextfollowup_dt')->useCurrent();

            $table->integer('staff_id')->default(0);
            $table->integer('staffhead_id')->default(0);
            $table->integer('management_id')->default(0);

            $table->string('staff_description', 100);
            $table->string('staffhead_description', 100);
            $table->string('management_description', 100);


            $table->integer('modeofconversation_id_fk')->default(0);




            $table->boolean('bactive')->default(true);
            $table->integer('user_created')->default(0);
            $table->integer('user_updated')->default(0);
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('lead_followups');
    }
}
