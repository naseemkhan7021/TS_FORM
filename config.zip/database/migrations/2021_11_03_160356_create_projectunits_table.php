<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProjectunitsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('projectunits', function (Blueprint $table) {
            $table->id('iID');
            $table->unsignedBigInteger('iProjectID_FK')->default(1);
            $table->foreign('iProjectID_FK')->references('ProjectID')->on('projects')->onDelete('cascade');
            $table->unsignedBigInteger('iProjectWingID_FK')->default(1);
            $table->foreign('iProjectWingID_FK')->references('iProjectWingID')->on('projectwings')->onDelete('cascade');
            $table->unsignedBigInteger('salesunitid_FK')->default(1);
            $table->foreign('salesunitid_FK')->references('salesunit_id')->on('salesunits')->onDelete('cascade');
            $table->string('iProjectUnitID',10)->default('101');
            $table->string('sManagementUnitID',10)->default('101');
            $table->decimal('iCarpetArea_sqmt',10,3)->default(0);
            $table->decimal('iBuildUpFormula',10,3)->default(0);
            $table->decimal('iBuildArea_sqmt',10,3)->default(0);
            $table->decimal('iOpenArea',10,3)->default(0);
            $table->decimal('iStampDutyArea',10,3)->default(0);
            $table->decimal('iStampDutyArea2',10,3)->default(0);
            $table->decimal('iTotalCarpetArea_sqft',10,3)->default(0);
            $table->decimal('iOtla_Area',10,3)->default(0);
            $table->decimal('iTotalArea_sqft',10,3)->default(0);
            $table->decimal('iMarketRate_sqmt',15,3)->default(0);
            $table->decimal('iMarketValue_sqmt',15,3)->default(0);
            $table->decimal('iAgreementValue',15,3)->default(0);
            $table->decimal('iRate_sqft',15,3)->default(0);
            $table->decimal('iFloorRiseRate',15,3)->default(0);
            $table->decimal('iFloorRiseAmount',15,3)->default(0);
            $table->decimal('mFlatCost',15,3)->default(0);
            $table->decimal('mDevelopmentCharges',15,3)->default(0);
            $table->decimal('mDevelopmentCharges_amt',15,3)->default(0);
            $table->decimal('mParking',15,3)->default(0);
            $table->decimal('mClubHouse',15,3)->default(0);
            $table->decimal('mGST',15,3)->default(0);
            $table->decimal('mTotalFlatCost',15,3)->default(0);
            $table->decimal('mRegistration',15,3)->default(0);
            $table->decimal('mStampDuty',15,3)->default(0);
            $table->decimal('mStampDutyPer',15,3)->default(0);
            $table->decimal('mGrandTotal',15,3)->default(0);


            $table->unsignedBigInteger('iSalesStatus_FK')->default(1);
            $table->foreign('iSalesStatus_FK')->references('sales_statuses_id')->on('sales_statuses')->onDelete('cascade');
            $table->unsignedBigInteger('iConstStatus_FK')->default(1);
            $table->foreign('iConstStatus_FK')->references('construction_stages_id')->on('construction_stages')->onDelete('cascade');
            $table->unsignedBigInteger('iReserved_FK')->default(1);
            // $table->foreign('iReserved_FK')->references('ProjectID')->on('projects')->onDelete('cascade');
            // $table->timestamp('dtReservedDate')->useCurrent();
            $table->unsignedBigInteger('iMemberID_FK')->default(0);
            // $table->foreign('iMemberID_FK')->references('ProjectID')->on('projects')->onDelete('cascade');


            $table->boolean('bactive')->default(true);
            $table->integer('user_created')->default(0);
            $table->integer('user_updated')->default(0);
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
        });
    }





    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('projectunits');
    }
}
