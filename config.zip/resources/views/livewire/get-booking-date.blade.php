<div>
    {{-- @if ( $primarymemberdata )
        {{ $primarymemberdata[0]->dtDOBK }}
    @else
        'NO DATA FOUND';
    @endif --}}
    SHAH YUNUS SALEEM
    {{ $primarymemberdata }}

</div>
